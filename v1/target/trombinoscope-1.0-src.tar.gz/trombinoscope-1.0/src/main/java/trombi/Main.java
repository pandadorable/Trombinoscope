package trombi;
import trombi.CAMERA.*;

public class Main {
    public static void main(String[] args) {
        CameraManager cameraManager = new CameraManager();
        CameraWindow cameraWindow = new CameraWindow(cameraManager);

        
    }
}